package se.pitch.sushifederation.consumption;

public class ConsumptionInternalError extends Exception {
  public ConsumptionInternalError(String s) {
    super(s);
  }
} 
