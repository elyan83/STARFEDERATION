
//Title:        Viewer Federate Public Names
//Version:      
//Copyright:    Copyright (c) 1998
//Author:       Frederick Kuhl
//Company:      The MITRE corporation
//Description:  Your description


package se.pitch.starfederation.viewer;

public class ViewerNames {
  //federate type
  public static final String _federateType = "Viewer";
}
