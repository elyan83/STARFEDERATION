package se.pitch.starfederation.production;

public class ProductionNames {
   //federate type
   public static final String _federateType = "Production";
}
