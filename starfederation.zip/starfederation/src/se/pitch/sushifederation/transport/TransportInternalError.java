package se.pitch.sushifederation.transport;

public class TransportInternalError extends Exception {
  public TransportInternalError(String s) {
    super(s);
  }
} 
