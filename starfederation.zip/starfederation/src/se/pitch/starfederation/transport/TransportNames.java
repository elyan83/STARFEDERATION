package se.pitch.starfederation.transport;

public class TransportNames {
  //federate type
  public static final String _federateType = "Transport";
}
