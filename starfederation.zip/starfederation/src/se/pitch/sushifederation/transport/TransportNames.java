package se.pitch.sushifederation.transport;

public class TransportNames {
  //federate type
  public static final String _federateType = "Transport";
}
