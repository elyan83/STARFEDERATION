package se.pitch.sushifederation.production;

public class ProductionInternalError extends Exception {
   public ProductionInternalError(String s) {
      super(s);
   }
} 
