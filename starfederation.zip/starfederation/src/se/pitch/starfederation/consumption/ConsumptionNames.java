package se.pitch.starfederation.consumption;

public class ConsumptionNames {
  //federate type
  public static final String _federateType = "Consumption";
}
