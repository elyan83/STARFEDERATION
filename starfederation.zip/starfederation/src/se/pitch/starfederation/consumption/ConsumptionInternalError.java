package se.pitch.starfederation.consumption;

public class ConsumptionInternalError extends Exception {
  public ConsumptionInternalError(String s) {
    super(s);
  }
} 
