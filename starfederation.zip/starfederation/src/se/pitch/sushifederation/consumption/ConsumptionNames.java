package se.pitch.sushifederation.consumption;

public class ConsumptionNames {
  //federate type
  public static final String _federateType = "Consumption";
}
