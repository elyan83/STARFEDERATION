package se.pitch.sushifederation.manager;

public class ManagerInternalError extends Exception {
  public ManagerInternalError(String s) {
    super(s);
  }
} 
