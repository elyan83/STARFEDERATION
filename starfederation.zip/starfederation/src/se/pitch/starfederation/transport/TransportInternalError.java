package se.pitch.starfederation.transport;

public class TransportInternalError extends Exception {
  public TransportInternalError(String s) {
    super(s);
  }
} 
