package se.pitch.starfederation.production;

public class ProductionInternalError extends Exception {
   public ProductionInternalError(String s) {
      super(s);
   }
} 
