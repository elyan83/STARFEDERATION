package se.pitch.sushifederation.production;

public class ProductionNames {
   //federate type
   public static final String _federateType = "Production";
}
